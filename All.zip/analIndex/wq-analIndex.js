toggle_side_menu();
initSession();
