var QuizTitles = [
  ['Kombinatorika', './kombiIndex.html'],
  ['Matematická analýza', './analIndex.html'],
  ['Kvíz 3. Obvody a obsahy geometrických obrazců', './obvody.html']
];
// construct the drop down menu if QuizTitles has some entries
if (QuizTitles.length > 0 && quizindex_menu) {
    create_quizindex_menu();
}
